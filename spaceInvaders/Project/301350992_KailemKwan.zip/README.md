Kailem Kwan
301350992
kailemk@sfu.ca

Assignment 1: Space Invaders 

Help I got: 
	CMPT 361 Triangle lecture notes
	CMPT 361 GLSL lecture notes
	CMPT 361 Programming tutorial
	CMPT 361 code from triangle.html and triangle.js
	https://www.codespeedy.com/detect-arrow-key-press-in-javascript/
	https://stackoverflow.com/questions/10311341/confirmation-before-closing-of-tab-browser
	https://stackoverflow.com/questions/28614956/webgl-adding-multiple-objects-to-one-canvas
	https://www.w3schools.com/jsref/met_loc_reload.asp
	https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/splice